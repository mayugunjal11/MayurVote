package Pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.VotingDaoImpl;
import Pojo.Voter;


@WebServlet("/register")
public class RegisterServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	private VotingDaoImpl dao;
	
	@Override
	public void init() throws ServletException 
	{
		try
		{
			dao=new VotingDaoImpl();
		}
		catch (Exception e) 
		{
			throw new ServletException("err in init"+getClass().getName(),e);
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		try(PrintWriter pw=response.getWriter())
		{
			/*HttpSession hs=request.getSession();
			Voter v1=(Voter)hs.getAttribute("voter_detail");
			VotingDaoImpl dao=(VotingDaoImpl) hs.getAttribute("voter_dao");
			
			if(v1.getRole().equals("admin"))
			{

				
			}*/

			
			String email=request.getParameter("em");
			String password=request.getParameter("pass");
			String status=request.getParameter("stat");
			String role=request.getParameter("role");
			
			Voter v=new Voter();
			
			v.setEmail(email);
			v.setPassword(password);
			v.setStatus(status);
			v.setRole(role);
			
			System.out.println(v.toString());
			
			String msg = dao.registerCustomer(v);
			 
		 	if(msg.equals("Customer reged successfully "))
			 {
				response.sendRedirect("login.html");
			 }
			 else
			 {
				 pw.print("<h1>failes register</h1>");
			 }

		}
		catch (Exception e)
		{
			throw new ServletException("problem with doPost"+getClass().getName()+e);
		}

	}
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package Pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.VotingDaoImpl;
import Pojo.Voter;

@WebServlet("/status")
public class StatusServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	@Override
		/*public void init() throws ServletException 
		{
			// TODO Auto-generated method stub
			super.init();
			try {
				dao=new VotingDaoImpl();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		response.setContentType("text/html");
		try(PrintWriter pw=response.getWriter())
		{
			HttpSession hs=request.getSession();
			
			Voter v=(Voter)hs.getAttribute("voter_detail");
			VotingDaoImpl dao=(VotingDaoImpl) hs.getAttribute("voter_dao");
			//Candidate c=(Candidate)hs.getAttribute("candidate_dao");
			
			
			if(v!=null)
			{
				String candidateId=request.getParameter("c_id");
				
				
				//System.out.println(v.toString());
				//pw.print(candidateId);
				
				String msg=dao.incrementVotes(candidateId,v.getEmail());
				
				if(msg.equals("vote done"))
				{
					pw.print("Hello,"+v.getEmail()+" you have voted succesfully");
					pw.print("<h5><a href=index.html>Visit Again</a></h5>");
					
					
					//dao.incrementVotes(v.getEmail());
				}
				else
				{
					response.sendRedirect("list");
				}
			}
			
			hs.invalidate();
			
			
		}
		 catch (Exception e) {
			// TODO: handle exception
		}
	}

}

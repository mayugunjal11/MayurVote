package Pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.VotingDaoImpl;
import Pojo.Candidate;
import Pojo.Voter;


@WebServlet("/admin")
public class AdminServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
	
		response.setContentType("text/html");
		try(PrintWriter pw=response.getWriter())
		{
			pw.print("welcome Admin");
			
			HttpSession hs = request.getSession();
			
			Voter c=(Voter)hs.getAttribute("voter_detail");
			VotingDaoImpl dao=(VotingDaoImpl) hs.getAttribute("voter_dao");
			
			
			if(c!=null)
			{
				List<Candidate> candidates=dao.maxvote();
				
				for(Candidate c1  : candidates)
				{
					pw.print("<h1>"+c1.getName()+"\t"+c1.getVotes()+"</h1>");
					
				}
				
			}
			else
				pw.print("<h5>Session tracking failed : no cookies</h5>");
			
			pw.print("<h4> To add User <a href=reg_form.html>new user</a></h4>");
			
			pw.print("<h5><a href=index.html>Visit Again</a></h5>");
			
			pw.print("<h5><a href=logout>Logout</a></h5>");
			

		}
		catch (Exception e)
		{
				throw new ServletException("err in do-get of " + getClass().getName(), e);
		}
		
	}

}

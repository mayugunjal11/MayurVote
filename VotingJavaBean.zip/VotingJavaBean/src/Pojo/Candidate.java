package Pojo;

public class Candidate
{
	private int id;
	private String name;
	private String political_party;
	private int votes;
	
	public Candidate()
	{	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPolitical_party() {
		return political_party;
	}

	public void setPolitical_party(String political_party) {
		this.political_party = political_party;
	}

	public int getVotes() {
		return votes;
	}

	public void setVotes(int votes) {
		this.votes = votes;
	}

	@Override
	public String toString() {
		return "Candidate [id=" + id + ", name=" + name + ", political_party=" + political_party + ", votes=" + votes
				+ "]";
	}

	
	
	
}

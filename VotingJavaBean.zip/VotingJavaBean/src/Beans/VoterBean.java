package Beans;



import Dao.VotingDaoImpl;
import Pojo.Voter;

public class VoterBean 
{
	private String c_id;
	private String email, password;
	private String status,role;
	private Voter validVoter;
	private VotingDaoImpl dao;
	
	

	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getC_id() {
		return c_id;
	}

	public void setC_id(String c_id) {
		this.c_id = c_id;
	}

	public VoterBean() throws Exception 
	{
		//validVoter=new Voter();
		dao=new VotingDaoImpl();
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Voter getValidVoter() {
		return validVoter;
	}

	public void setValidVoter(Voter validVoter) {
		this.validVoter = validVoter;
	}

	public VotingDaoImpl getDao() {
		return dao;
	}

	public void setDao(VotingDaoImpl dao) {
		this.dao = dao;
	}
	
	
	
	
	public String registerCustomer() throws Exception
	{
		Voter v=new Voter();
		
		v.setEmail(email);
		v.setPassword(password);
		v.setStatus(status);
		v.setRole(role);
		
		System.out.println(v.toString());
		
		dao.registerCustomer(v);
		return "login";
	}
	
	public String incrementVotes(String email) throws Exception
	{
		String msg=dao.incrementVotes(c_id, email);
		System.out.println(c_id);
		System.out.println(email);
		return msg;
	}
	
	
	public String validateVoter() throws Exception 
	{
		validVoter=dao.authenticateVoter(email, password);
		
		if(validVoter==null)
		{
			return"login";
		}
		else if(validVoter.getRole().equals("admin"))
		{
			return "admin"; 
		}
		else if(validVoter.getStatus().equals("false"))
		{
			return "list";
		}
		else
			return "test";
			
	}

}

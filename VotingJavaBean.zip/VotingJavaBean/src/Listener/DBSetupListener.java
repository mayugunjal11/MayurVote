package Listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import Utils.DBUtils;


@WebListener
public class DBSetupListener implements ServletContextListener 
{

    public DBSetupListener() 
    {
       
    }

    public void contextDestroyed(ServletContextEvent arg0) 
    { 
    	System.out.println("in ctx destroyed...");
		try 
		{
			DBUtils.cleanUp();
		} catch (Exception e) {
			System.out.println("err in ctx destroyed " + e);
		}   
    }

	
    public void contextInitialized(ServletContextEvent arg0)  
    { 
    	System.out.println("in ctx init...");
    	ServletContext ctx=arg0.getServletContext();
    	
    	try 
    	{
    		DBUtils.setUp(ctx.getInitParameter("driver"),ctx.getInitParameter("url"),ctx.getInitParameter("user"), ctx.getInitParameter("password"));
		} 
    	catch (Exception e) 
    	{
    		System.out.println("err in ctx inited " + e);
		}
    	System.out.println("connection established");
    }
	
}

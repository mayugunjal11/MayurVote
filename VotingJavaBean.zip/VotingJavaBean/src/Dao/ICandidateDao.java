package Dao;

public interface ICandidateDao 
{

}

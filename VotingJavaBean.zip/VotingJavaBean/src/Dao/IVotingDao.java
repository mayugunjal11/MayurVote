package Dao;

import java.util.List;

import Pojo.Candidate;
import Pojo.Voter;

public interface IVotingDao 
{
	 Voter authenticateVoter(String em,String pass) throws Exception;
	
	 List<Candidate> getCandidateList() throws Exception;
	 List<Candidate> maxvote() throws Exception;
	 
	 String incrementVotes(String candidateId,String email) throws Exception;
	 
	 
	 String registerCustomer(Voter v) throws Exception;
}

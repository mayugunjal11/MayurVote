package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Pojo.Candidate;
import Pojo.Voter;


import static Utils.DBUtils.*;

public class VotingDaoImpl implements IVotingDao
{

	private Connection cn;
	private PreparedStatement pst1;
	private PreparedStatement pst2;
	private PreparedStatement pst3;
	private PreparedStatement pst33;
	private PreparedStatement pst4;
	private PreparedStatement pstregister;
	

	public VotingDaoImpl() throws Exception {
		// get cn
		//cn = DBUtils.getCn();
		cn=getCn();
		pst1=cn.prepareStatement("select * from voters where email=? and password=?");
		pst2 = cn.prepareStatement("select name,political_party,votes from candidates");
		
		pst3=cn.prepareStatement("update candidates set votes=votes+1 where name=?");
		pst33=cn.prepareStatement("update voters set status='true' where email=?");
		
		pst4=cn.prepareStatement("select name,votes from candidates where votes >=(select max(votes) from candidates where votes < (select max(votes) from candidates)) order by votes desc");
		
		pstregister=cn.prepareStatement(" insert into voters(email,password,status,role)values(?,?,?,?)");
		System.out.println("book dao created");
	}

	// clean up
	public void cleanUp() throws Exception {
		if (pst1 != null)
			pst1.close();
		if (pst2 != null)
			pst2.close();
		if (pst3 != null)
			pst3.close();
		if (pst33 != null)
			pst33.close();
		if(pstregister!=null)
			pstregister.close();
		System.out.println("dao cleaned up.....");
	}

	


	
	@Override
	public Voter authenticateVoter(String em, String pass) throws Exception 
	{
		System.out.println(em+" "+pass);
		pst1.setString(1, em);
		pst1.setString(2, pass);
		
		try (ResultSet rst = pst1.executeQuery()) 
		{
			if (rst.next())
				return new Voter(rst.getString(2),rst.getString(3),rst.getString(4),rst.getString(5));
		}
		return null;
	}
	
	
	

	@Override
	public List<Candidate> getCandidateList() throws Exception 
	{
		// TODO Auto-generated method stub
		ArrayList<Candidate> cats=new ArrayList<>();
		try(ResultSet rst=pst2.executeQuery())
		{
			while(rst.next())
			{
				//System.out.println("mayur");
				
				String name=rst.getString(1);
				String political_party=rst.getString(2);
				int votes=rst.getInt(3);
				
				Candidate obj=new Candidate();
				
				obj.setName(name);
				obj.setPolitical_party(political_party);
				obj.setVotes(votes);
				obj.toString();
				
				cats.add(obj);
				
			}
				
		}
		System.out.println("dao creted "+cats);
		return cats;
	}

	
	
	@Override
	public String incrementVotes(String candidateId,String email) throws Exception
	{
		pst3.setString(1, candidateId);
		
		pst33.setString(1, email);
		
		int i=pst3.executeUpdate();
		int j=pst33.executeUpdate();
		if(i==1 || j==1)
			return "u have voted succesfully";
		return null;
	}

	@Override
	public List<Candidate> maxvote() throws Exception
	{
		ArrayList<Candidate> cats=new ArrayList<>();
		
		try(ResultSet rst=pst4.executeQuery())
		{
			while(rst.next())
			{
				//System.out.println("mayur in mxvote");
				
				String name=rst.getString(1);
				int votes=rst.getInt(2);
				
				
				Candidate obj=new Candidate();
				
				obj.setName(name);
				obj.setVotes(votes);
				
				//obj.toString();
				
				cats.add(obj);
				
			}
				
		}
		System.out.println("dao creted "+cats);
		return cats;
	}

	@Override
	public String registerCustomer(Voter v) throws Exception 
	{
		pstregister.setString(1, v.getEmail());
		pstregister.setString(2, v.getPassword());
		pstregister.setString(3, v.getStatus());
		pstregister.setString(4, v.getRole());
		
		
		// exec update
		int updateCount = pstregister.executeUpdate();
		System.out.println(updateCount);
		if (updateCount == 1)
			return "Customer reged successfully ";
		return "Customer registration failed....";
	}

}

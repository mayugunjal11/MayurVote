package Utils;

import java.sql.*;

public class DBUtils
{
	private static Connection cn;

	public static void setUp(String driver,String url,String user,String password) throws Exception 
	{
		
		Class.forName(driver);
		
		cn = DriverManager.getConnection(url,user,password);
		System.out.println("db cn established...");
	}

	public static Connection getCn()
	{
		return cn;
	}

	public static void cleanUp() throws Exception 
	{
		if (cn != null)
			cn.close();
		System.out.println("db cn closed...");
	}
}
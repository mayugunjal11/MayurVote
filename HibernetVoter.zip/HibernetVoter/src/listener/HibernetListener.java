package listener;
import utils.HibernateUtils;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class HibernetListener implements ServletContextListener {


    public HibernetListener() {
        // TODO Auto-generated constructor stub
    }

    public void contextDestroyed(ServletContextEvent arg0) 
    { 
    	System.out.println("in ctx destroyed.");
        HibernateUtils.getSf().close();
    }

    public void contextInitialized(ServletContextEvent arg0)  
    { 
    	System.out.println("in ctx inited");
        HibernateUtils.getSf();
    }
	
}

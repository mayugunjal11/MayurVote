package Dao;

public class CandidateDaoImpl implements ICandidateDao 
{

}

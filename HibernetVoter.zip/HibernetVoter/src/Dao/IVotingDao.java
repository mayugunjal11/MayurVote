package Dao;

import java.util.List;

import Pojo.Candidate;
import Pojo.Voter;

public interface IVotingDao 
{
	 Voter authenticateVoter(String em,String pass) ;
	
	 List<Candidate> getCandidateList() ;
	 
	 List<Candidate> maxvote() ;
	 
	 String incrementVotes(Integer candidateId,String email) ;
	 
	 
	 String registerCustomer(Voter v) ;
}

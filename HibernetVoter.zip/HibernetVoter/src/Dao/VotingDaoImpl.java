package Dao;

import java.util.ArrayList;
import java.util.List;
import Pojo.Candidate;
import Pojo.Voter;
import org.hibernate.*;
import static utils.HibernateUtils.*;


public class VotingDaoImpl implements IVotingDao
{
	@Override
	public Voter authenticateVoter(String em, String pass)
	{
		System.out.println("dao : validate query");
		String jpql = "select v from Voter v where v.email=:em and v.password=:pass";
		Voter v = null;
		
		Session hs=getSf().getCurrentSession();
		Transaction tx=hs.beginTransaction();
		try
		{
			v=hs.createQuery(jpql, Voter.class).setParameter("em", em).setParameter("pass", pass).getSingleResult();
			tx.commit();
		} 
		catch (RuntimeException e)
		{
			if (tx != null)
				tx.rollback();//L1 cache destroyed n pooled out db cn rets to the pool
			throw e;
		}
		return v;
	}
	
	
	

	@Override
	public List<Candidate> getCandidateList()
	{
		// TODO Auto-generated method stub
		ArrayList<Candidate> cats=null;
		String jpql="select c from Candidate c";
		
		
		Session hs=getSf().getCurrentSession();
		Transaction tx=hs.beginTransaction();
		
		try
		{
			cats=(ArrayList<Candidate>) hs.createQuery(jpql, Candidate.class).getResultList();
			tx.commit();
		} 
		catch (HibernateException e)
		{
			if (tx != null)
				tx.rollback();//L1 cache destroyed n pooled out db cn rets to the pool
			throw e;
		}
		
		
		System.out.println("dao creted "+cats);
		return cats;
	}

	
	
	@Override
	public String incrementVotes(Integer candidateId,String email)
	{
		
		String mesg = "User details not updated";
		String jpql1="select v from Voter v where v.email=:email";
		
		Voter v=null;
		Candidate c=null;
		
		Session hs=getSf().getCurrentSession();
		Transaction tx=hs.beginTransaction();
		
		try
		{

			v=hs.createQuery(jpql1, Voter.class).setParameter("email",email).getSingleResult();
			c=hs.get(Candidate.class, candidateId);
			
			if(v!=null || c!=null)
			{
				v.setStatus("true");
				c.setVotes(c.getVotes()+1);
			}
			tx.commit();
			mesg="u have voted succesfully";
		} 
		catch (HibernateException e)
		{
			if (tx != null)
				tx.rollback();//L1 cache destroyed n pooled out db cn rets to the pool
			throw e;
		}
		
		return mesg;
	}

	@Override
	public List<Candidate> maxvote()
	{
		
		List<Candidate> c=null;
		
		String jpql="select c from Candidate c where c.votes >=(select max(c.votes) from Candidate c where c.votes < (select max(c.votes) from Candidate c)) order by c.votes desc";
		
		Session hs=getSf().getCurrentSession();
		Transaction tx=hs.beginTransaction();
		
		try
		{
			c=hs.createQuery(jpql,Candidate.class).setMaxResults(2).getResultList();
			tx.commit();
		} 
		catch (HibernateException e)
		{
			if (tx != null)
				tx.rollback();//L1 cache destroyed n pooled out db cn rets to the pool
			throw e;
		}
		
		System.out.println("dao creted "+c);
		return c;
	}

	@Override
	public String registerCustomer(Voter v) 
	{
		Session hs=getSf().getCurrentSession();
		Transaction tx=hs.beginTransaction();
		
		String msg="";
		
		try
		{
			hs.save(v);
			tx.commit();
			msg="Customer reged successfully ";
		} 
		catch (HibernateException e)
		{
			if (tx != null)
				tx.rollback();//L1 cache destroyed n pooled out db cn rets to the pool
			throw e;
		}
		return msg;
	}

}

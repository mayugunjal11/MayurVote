package Beans;



import Dao.VotingDaoImpl;
import Pojo.Voter;

public class VoterBean 
{
	private Integer v_id;
	private Integer c_id;
	private String email, password;
	private String status,role;
	private Voter validVoter;
	private VotingDaoImpl dao;
	
	
	

	
	public Integer getV_id() {
		return v_id;
	}

	public void setV_id(Integer v_id) {
		this.v_id = v_id;
	}

	public Integer getC_id() {
		return c_id;
	}

	public void setC_id(Integer c_id) {
		this.c_id = c_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	

	public VoterBean() throws Exception 
	{
		//validVoter=new Voter();
		dao=new VotingDaoImpl();
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Voter getValidVoter() {
		return validVoter;
	}

	public void setValidVoter(Voter validVoter) {
		this.validVoter = validVoter;
	}

	public VotingDaoImpl getDao() {
		return dao;
	}

	public void setDao(VotingDaoImpl dao) {
		this.dao = dao;
	}
	
	
	
	
	public String registerCustomer() throws Exception
	{
		Voter v=new Voter();
		
		v.setEmail(email);
		v.setPassword(password);
		v.setStatus(status);
		v.setRole(role);
		
		System.out.println(v.toString());
		
		dao.registerCustomer(v);
		return "login";
	}
	
	public String incrementVotes(String email) throws Exception
	{
		System.out.println(c_id);
		System.out.println(email);
		String msg=dao.incrementVotes(c_id, email);
		
		return msg;
	}
	
	
	public String validateVoter() throws Exception 
	{
		
		try
		{
			validVoter=dao.authenticateVoter(email, password);
		} 
		catch (RuntimeException e) 
		{
			if(validVoter==null)
			{
				return"login";
			}
		}
		
		if(validVoter.getRole().equals("admin"))
		{
			return "admin"; 
		}
		else if(validVoter.getStatus().equals("false"))
		{
			return "list";
		}
		else
			return "test";
			
	}

}

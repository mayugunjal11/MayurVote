package Beans;



import java.util.List;
import Dao.VotingDaoImpl;
import Pojo.Candidate;
import Pojo.Voter;

public class CandidateBean 
{
	private Voter validVoter;
	private VotingDaoImpl dao;

	

	public CandidateBean() throws Exception
	{
		dao=new VotingDaoImpl();
	}

	

	public Voter getValidVoter() {
		return validVoter;
	}

	public void setValidVoter(Voter validVoter) {
		this.validVoter = validVoter;
	}

	public VotingDaoImpl getDao() {
		return dao;
	}

	public void setDao(VotingDaoImpl dao) {
		this.dao = dao;
	}
	
	public List<Candidate> getCandidateList()throws Exception
	{
		return dao.getCandidateList();
	}
	
	public List<Candidate> maxvote() throws Exception
	{
		return dao.maxvote();	
	}
	
	

	
	
}



